package com.example.jpa_programming;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaProgrammingApplicationTests {

	@Test
	void contextLoads() {
	}

}
