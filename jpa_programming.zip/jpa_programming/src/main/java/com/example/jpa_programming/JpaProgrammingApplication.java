package com.example.jpa_programming;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaProgrammingApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpaProgrammingApplication.class, args);
	}

}
