package com.example.data_external;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DataExternalApplication {

	public static void main(String[] args) {
		SpringApplication.run(DataExternalApplication.class, args);
	}

}
