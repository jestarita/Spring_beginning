package com.example.data_external;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataExternalApplicationTests {

	@Test
	void contextLoads() {
	}

}
