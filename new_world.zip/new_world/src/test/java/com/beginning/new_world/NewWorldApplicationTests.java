package com.beginning.new_world;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewWorldApplicationTests {

	@Test
	void contextLoads() {
	}

}
