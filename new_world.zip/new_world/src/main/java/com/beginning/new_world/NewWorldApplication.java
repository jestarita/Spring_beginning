package com.beginning.new_world;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NewWorldApplication {

	public static void main(String[] args) {
		SpringApplication.run(NewWorldApplication.class, args);
	}

}
