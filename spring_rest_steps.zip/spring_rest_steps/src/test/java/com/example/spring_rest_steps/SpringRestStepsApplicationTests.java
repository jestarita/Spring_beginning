package com.example.spring_rest_steps;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRestStepsApplicationTests {

	@Test
	void contextLoads() {
	}

}
